WSEecoCreateOrderBrazil wr = new WSEecoCreateOrderBrazil();

wr.createOrder('{0}','M02');